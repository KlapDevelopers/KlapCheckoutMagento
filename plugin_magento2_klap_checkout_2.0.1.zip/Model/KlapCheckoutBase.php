<?php

namespace Klap\Checkout\Model;

/**
 * Pay In Store payment method model
 */
class KlapCheckoutBase extends \Magento\Payment\Model\Method\AbstractMethod {

  /**
   * Array of currency support
   */
  protected $_supportedCurrencyCodes = array('CLP');

  protected $_isGateway = true;
  protected $_canCapture = true;
  protected $_canRefund = false;
  protected $_canAuthorize = true;

  /**
   * Availability for currency
   *
   * @param string $currencyCode
   * @return bool
   */
  public function canUseForCurrency($currencyCode) {
    if (!in_array($currencyCode, $this->_supportedCurrencyCodes)) {
      return false;
    }
    return true;
  }

  public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount) {
    if (!$this->canCapture()) {
      throw new \Magento\Framework\Exception\LocalizedException(__('The capture action is not available.'));
    }
    return $this;
  }

  public function authorize(\Magento\Payment\Model\InfoInterface $payment, $amount) {
    if (!$this->canAuthorize()) {
      throw new \Magento\Framework\Exception\LocalizedException(__('The authorize action is not available.'));
    }
    return $this;
  }
}
