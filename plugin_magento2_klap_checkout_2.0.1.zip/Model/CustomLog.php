<?php

namespace Klap\Checkout\Model;

// carga el sdk de klap checkout
require_once(dirname(dirname(__FILE__)).'/sdk/src/init.php');

use \Multicaja\Payments\Utils\BasicLog;
use \Multicaja\Payments\Model\Error;

/**
 * Clase para escribir logs
 *
 * docs:
 * - https://framework.zend.com/manual/2.1/en/modules/zend.log.overview.html
 */
class CustomLog {

  /**
   * Instancia del custom logger en caso que falle log4php
   */
  private $basicLogger = null;

  /**
   * Instancia del logger de log4php
   */
  private $logger = null;

  public function __construct() {
  }

  /**
   * Lugar donde se guarda el archivo de log del plugin
   */
  public function getLogDir() {
    return BP . '/var/log/';
  }

  /**
   * Lugar donde se guarda el archivo de log del plugin
   */
  public function getLogFile() {
    return $this->getLogDir() . 'klap_checkout.log';
  }

  /**
   * Retorna el logger
   */
  public function getLogger() {
    if ($this->basicLogger == null) {
      $this->basicLogger = new \Multicaja\Payments\Utils\BasicLog();
    }
    try {
      if ($this->logger == null) {
        if (!file_exists($this->getLogDir())) {
          mkdir($this->getLogDir(), 0777, true);
        }
        if (!file_exists($this->getLogFile()) && is_writable($this->getLogDir())) {
          touch($this->getLogFile());
        }
        if (is_writable($this->getLogFile())) {
          $writer = new \Zend\Log\Writer\Stream($this->getLogFile());
          $this->logger = new \Zend\Log\Logger();
          $this->logger->addWriter($writer);
        }
      }
    } catch(Exception $ex) {
      return new Error('1', 'Error al obtener logger');
    }
    return $this->logger != null ? $this->logger : $this->basicLogger;
  }

  /**
   * Imprime un mensaje info en el logger
   */
  public function info($msg) {
    $this->getLogger()->info($msg);
  }

  /**
   * Imprime un mensaje error en el logger
   */
  public function warn($msg) {
    $this->getLogger()->warn($msg);
  }

  /**
   * Imprime un mensaje error en el logger
   */
  public function error($msg) {
    $this->getLogger()->err($msg);
  }
}
