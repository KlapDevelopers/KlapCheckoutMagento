define(
  [
    'jquery',
    'Magento_Checkout/js/view/payment/default'
  ],
  function ($,
    Component,
    placeOrderAction,
    selectPaymentMethodAction,
    customer,
    checkoutData,
    additionalValidators,
    url,
    quote) {
    'use strict';

    return Component.extend({
      defaults: {
        template: 'Klap_Checkout/payment/klap_checkout'
      },
      getCode: function() {
        return 'klap_sodexo';
      },
      getTitle: function() {
        return "Pago con tarjeta Sodexo";
      },
      getImg: function() {
        return "https://i.ibb.co/styjKkM/logo-sodexo.png";
      },
      getDescription: function() {
        return "Paga con tu rut y clave dinámica.";
      },
      placeOrder: function() {
        var guestEmail = undefined;
        if (quote && quote.guestEmail) {
          guestEmail = quote.guestEmail;
        }
        if (guestEmail == undefined || guestEmail == '') {
          guestEmail = $('#customer-email').val();
        }
        var endpoint = './klapcheckout/createorder?method=klap_sodexo';
        if (guestEmail != undefined) {
          endpoint+='&guestEmail=' + encodeURIComponent(guestEmail);
        }
        location.href = endpoint;
      }
    })
  }
);
