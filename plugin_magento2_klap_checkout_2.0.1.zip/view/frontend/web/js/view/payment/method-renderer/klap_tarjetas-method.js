define(
  [
    'jquery',
    'Magento_Checkout/js/view/payment/default'
  ],
  function ($,
    Component,
    placeOrderAction,
    selectPaymentMethodAction,
    customer,
    checkoutData,
    additionalValidators,
    url,
    quote) {
    'use strict';

    return Component.extend({
      defaults: {
        template: 'Klap_Checkout/payment/klap_checkout'
      },
      getCode: function() {
        return 'klap_tarjetas';
      },
      getTitle: function() {
        return "Pago con tarjetas de débito, crédito y prepago";
      },
      getImg: function() {
        return "https://i.ibb.co/K02yQCL/logo-visa-master-klap.png";
      },
      getDescription: function() {
        return "Paga con tarjeta de crédito, débito y/o Prepago (Visa y Mastercard)";
      },
      placeOrder: function() {
        var guestEmail = undefined;
        if (quote && quote.guestEmail) {
          guestEmail = quote.guestEmail;
        }
        if (guestEmail == undefined || guestEmail == '') {
          guestEmail = $('#customer-email').val();
        }
        var endpoint = './klapcheckout/createorder?method=klap_tarjetas';
        if (guestEmail != undefined) {
          endpoint+='&guestEmail=' + encodeURIComponent(guestEmail);
        }
        location.href = endpoint;
      }
    })
  }
);
