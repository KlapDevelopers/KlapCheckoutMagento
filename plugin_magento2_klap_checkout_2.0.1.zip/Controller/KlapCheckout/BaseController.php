<?php

namespace Klap\Checkout\Controller\KlapCheckout;

// carga el sdk de klap checkout
require_once(dirname(dirname(dirname(__FILE__))).'/sdk/src/init.php');

use Klap\Checkout\Model\HelperPasarela;
use Klap\Checkout\Model\ConfigProvider;

/**
 * Controller for callback handler
 *
 * docs:
 * - https://github.com/magento/magento2/blob/2.2/app/code/Magento/Framework/App/Action/Context.php
 * - https://github.com/magento/magento2/blob/2.2/app/code/Magento/Checkout/Model/Cart.php
 * - https://github.com/magento/magento2/blob/2.2/app/code/Magento/Checkout/Model/Session.php
 * - https://github.com/magento/magento2/blob/2.2/app/code/Magento/Customer/Model/Session.php
 * - https://github.com/magento/magento2/blob/2.2/app/code/Magento/Sales/Model/Order/Status/History.php
 * - https://github.com/magento/magento2/blob/2.2/app/code/Magento/Sales/Api/Data/OrderStatusHistoryInterface.php
 *
 */
abstract class BaseController extends \Magento\Framework\App\Action\Action {

  protected $hp;
  protected $logger = null;

  public function __construct(\Magento\Framework\App\Action\Context $context,
                              \Magento\Checkout\Model\Cart $cart,
                              \Magento\Checkout\Model\Session $checkoutSession,
                              \Magento\Customer\Model\Session $customerSession,
                              \Magento\Quote\Model\QuoteManagement $quoteManagement,
                              \Magento\Store\Model\StoreManagerInterface $storeManager,
                              \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfigInterface,
                              \Magento\Framework\Module\ModuleListInterface $moduleListInterface) {

      parent::__construct($context);

      $this->_cart = $cart;
      $this->_checkoutSession = $checkoutSession;
      $this->_customerSession = $customerSession;
      $this->_quoteManagement = $quoteManagement;
      $this->_storeManager = $storeManager;
      $this->_messageManager = $context->getMessageManager();

      $configProvider = new ConfigProvider($scopeConfigInterface, $moduleListInterface, $storeManager);
      $this->hp = new HelperPasarela($configProvider, 'MCP_');
      $this->logger = $this->hp->getLogger();
  }

  /**
   * Agrega un metadato a la orden
   */
  protected function addMetadataToOrder($orderEcommerce, $key, $value) {
    $message = $key . '=' . $value;
    $orderEcommerce->addStatusToHistory($orderEcommerce->getStatus(), $message);
  }

  /**
   * Retorna un metadato de la orden por su llave
   */
  protected function getMetadataFromOrder($messages, $key) {
    foreach ($messages as &$msg) {
      $value = $msg->getComment();
      if ($this->startsWith($value, $key . '=')) {
        return explode('=', $value)[1];
      }
    }
    return '';
  }

  /**
   * Retorna la fecha formateada con zona horaria
   */
  protected function getCurrentDateTime() {
    date_default_timezone_set('America/Santiago');
    return date('Y-m-d H:i:s');
  }


  protected function getOrder($orderId = null) {
    try {
      if ($orderId == null) {
        $orderId = $this->_checkoutSession->getLastOrderId();
      }
      if ($orderId == null) {
        return null;
      }
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
      return $objectManager->create('\Magento\Sales\Model\Order')->load($orderId);
    } catch (Exception $e) {
        return null;
    }
  }

  protected function endsWith($haystack, $needle) {
    $length = strlen($needle);
    if ($length == 0) {
      return true;
    }
    return (substr($haystack, -$length) === $needle);
  }

  protected function startsWith($string, $startString) {
    $len = strlen($startString);
    return (substr($string, 0, $len) === $startString);
  }
}
