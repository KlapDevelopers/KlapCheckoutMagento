<?php

namespace Klap\Checkout\Controller\KlapCheckout;

use Klap\Checkout\Controller\KlapCheckout\BaseController;

use \Multicaja\Payments\Model\AmountDetails;
use \Multicaja\Payments\Model\Amount;
use \Multicaja\Payments\Model\User;
use \Multicaja\Payments\Model\Item;
use \Multicaja\Payments\Model\Custom;
use \Multicaja\Payments\Model\Urls;
use \Multicaja\Payments\Model\Webhooks;
use \Multicaja\Payments\Model\Method;
use \Multicaja\Payments\Model\Error;
use \Multicaja\Payments\Model\OrderRequest;
use \Multicaja\Payments\Model\OrderResponse;
use \Multicaja\Payments\Utils\PaymentsApiClient;
use \Multicaja\Payments\Utils\ValidateParams;

/**
 * Controller para crear la orden y redireccionar a klap checkout
 */
class CreateOrderLegacy extends BaseController {

  public function __construct(\Magento\Framework\App\Action\Context $context,
                              \Magento\Checkout\Model\Cart $cart,
                              \Magento\Checkout\Model\Session $checkoutSession,
                              \Magento\Customer\Model\Session $customerSession,
                              \Magento\Quote\Model\QuoteManagement $quoteManagement,
                              \Magento\Store\Model\StoreManagerInterface $storeManager,
                              \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfigInterface,
                              \Magento\Framework\Module\ModuleListInterface $moduleListInterface) {

    parent::__construct(
      $context, $cart, $checkoutSession, $customerSession,
      $quoteManagement, $storeManager,
      $scopeConfigInterface, $moduleListInterface);
  }

  const TARJETAS = 'klap_tarjetas';
  const SODEXO = 'klap_sodexo';
  const EFECTIVO_TRANSFERENCIA = 'klap_efectivo_transferencia';
  const VALUE = 'value';
  const REFERENCE_ID = 'reference_id';
  const ORDER_ID = 'order_id';
  const AMOUNT = 'amount';
  const PURCHASE_DATE = 'purchase_date';
  const MAGENTO = 'MAGENTO';

  /**
   * Metodo por defecto a implementar en los controladores de Magento 2
   */
  public function execute() {

    $referenceId = 0;

    try {
      $method = $_GET['method'];
      $this->hp->setMethod($method);
      $this->logger->info('Creando orden metodo de pago: ' . $method);
      $orderStatusPendingPayment = $this->hp->getOrderStatusPendingPayment();

      $tmpOrder = $this->getOrder();

      if ($tmpOrder != null && $tmpOrder->getStatus() == $orderStatusPendingPayment) {
        $orderStatusCanceled = $this->hp->getOrderStatusFailed();
        $tmpOrder->setState($orderStatusCanceled)->setStatus($orderStatusCanceled);
        $tmpOrder->save();
        $this->_checkoutSession->restoreQuote();
      }

      $quote = $this->_cart->getQuote();

      //si el usuario no se encuentra logeado, se debe obtener el email de invitado
      if (!$this->_customerSession->isLoggedIn()) {
        $guestEmail = isset($_GET['guestEmail']) ? $_GET['guestEmail'] : null;
        if ($guestEmail != null && $guestEmail != '') {
          $this->logger->info('usuario invitado, guestEmail: ' . $guestEmail);
          $quote->getBillingAddress()->setEmail($guestEmail);
          $quote->setData('customer_email', $quote->getBillingAddress()->getEmail());
          $quote->setData('customer_firstname', $quote->getBillingAddress()->getFirstName());
          $quote->setData('customer_lastname', $quote->getBillingAddress()->getLastName());
          $quote->setData('customer_is_guest', 1);
        }
      }

      $quote->getPayment()->importData(['method' => $method]);
      $quote->collectTotals()->save();
      $orderEcommerce = $this->_quoteManagement->submit($quote);

      $this->_checkoutSession->setLastQuoteId($quote->getId());
      $this->_checkoutSession->setLastSuccessQuoteId($quote->getId());
      $this->_checkoutSession->setLastOrderId($orderEcommerce->getId());
      $this->_checkoutSession->setLastRealOrderId($orderEcommerce->getIncrementId());
      $this->_checkoutSession->setLastOrderStatus($orderEcommerce->getStatus());
      $this->_checkoutSession->setGrandTotal(intval(round($quote->getGrandTotal())));

      $referenceId = $orderEcommerce->getId();

      $returnUrl = $this->hp->getReturnUrl();
      $cancelUrl = $this->hp->getCancelUrl();
      $logoUrl = $this->hp->getLogoUrl();
      $webhookConfirm = $this->hp->getWebhookConfirm();
      $webhookReject = $this->hp->getWebhookReject();
      $runtimeInfo = $this->hp->getRuntimeInfo();
      $ecommerceInfo = $this->hp->getEcommerceInfo();
      $description = null;
      $amount = intval(round($quote->getGrandTotal()));

      $orderRequest = new OrderRequest();

      //agrega los items del carro a los items de la orden
      $cartItems = $quote->getAllVisibleItems();
      foreach($cartItems as $cartItem) {
        $name = strval($cartItem->getName());
        $code = strval($cartItem->getSku());
        $quantity = intval($cartItem->getQty());
        $unitPrice = intval(round($cartItem->getPriceInclTax()));
        $price = $unitPrice * $quantity;
        $orderRequest->addItem(new Item($name, $code, $price, $unitPrice, $quantity));
        $description = $name;
      }

      //agrega el costo de envio a los items de la orden
      $shippingPrice = intval(round($quote->getShippingAddress()->getShippingAmount()));
      if ($shippingPrice != 0) {
        $name = 'Costo por envio';
        $code = 'Envio';
        $quantity = 1;
        $price = $shippingPrice;
        $orderRequest->addItem(new Item($name, $code, $price, $price, $quantity));
      }

      if ($description == null) {
        $description = 'Compra de varios productos';
      }

      //si el valor de logo_url no es una url se reescribe en null para evitar error en Klap Checkout
      if (filter_var($logoUrl, FILTER_VALIDATE_URL) === FALSE) {
        $logoUrl = null;
      }

      /**
      * Validar monto mayor a 50 pesos
      */
      if ($amount < 50) {
        throw new \InvalidArgumentException('El monto de compra debe ser de al menos $50 pesos.');
      }

      $user["rut"]= null;
      $user["email"] = null;
      $user["first_name"] = null;
      $user["last_name"] = null;
      $user["phone"] = null;
      $user["address_line"] = null;
      $user["address_city"] = null;
      $user["address_state"] = null;
      $orderRequest->setUser(new User($user));

      $orderRequest->setReferenceId((string)$referenceId);
      $orderRequest->setDescription($description);
      $orderRequest->setAmount(new Amount('CLP', $amount));
      $orderRequest->addCustom(array('key' => 'plugin_version', self::VALUE => $this->hp->getPluginVersion()));
      $orderRequest->addCustom(array('key' => 'plugin_ecommerce_runtime', self::VALUE => $runtimeInfo));
      $orderRequest->addCustom(array('key' => 'plugin_ecommerce_name', self::VALUE => $ecommerceInfo));
      $orderRequest->addCustom(array('key' => 'plugin_ecommerce_platform',  self::VALUE => self::MAGENTO));
      $orderRequest->addCustom(array('key' => 'payments_notify_user', self::VALUE => $this->hp->getPaymentsNotifyUser()));
      if($method === self::TARJETAS) {
          $orderRequest->setMethods(array('tarjetas'));
          $orderRequest->addCustom(array('key' => 'tarjetas_expiration_minutes', self::VALUE => $this->hp->getTarjetasExpirationMinutes()));
      }else if($method === self::EFECTIVO_TRANSFERENCIA){
          $orderRequest->setMethods(array('efectivo','transferencia'));
          $orderRequest->addCustom(array('key' => 'efectivo_expiration_minutes', self::VALUE => $this->hp->getEfectivoExpirationMinutes()));
          $orderRequest->addCustom(array('key' => 'transferencia_expiration_minutes', self::VALUE => $this->hp->getTransferenciaExpirationMinutes()));
      }else if($method === self::SODEXO){
          $orderRequest->setMethods(array('sodexo'));
          $orderRequest->addCustom(array('key' => 'sodexo_expiration_minutes', self::VALUE => $this->hp->getSodexoExpirationMinutes()));
      }
      $orderRequest->setUrls(new Urls($returnUrl, $cancelUrl, $logoUrl));
      $orderRequest->setWebhooks(new Webhooks(null, $webhookConfirm, $webhookReject));

      //crea la orden en klap
      try {
        $environment = $this->hp->getEnvironment();
        $apikey = $this->hp->getApiKey();
        $this->logger = $this->hp->getLogger();
        PaymentsApiClient::setLogger($this->logger);
        $response = PaymentsApiClient::createOrder($environment, $apikey, $orderRequest);
      } catch(Exception $ex) {
        $this->logger->error('Error al crear la orden: ' . $ex->getMessage());
        $response = new Error('0', 'Error al crear la orden');
      }

      if ($response == null) {
        throw new \InvalidArgumentException('Error al intentar conectar con klap Checkout, sin respuesta. Por favor intenta más tarde.');
      }

      if (!($response instanceof OrderResponse)) {
        $this->logger->error("Error: ".json_encode($response));
        throw new \InvalidArgumentException('Error en la respuesta de klap Checkout. Por favor intenta más tarde.');
      }

      if ($response->getRedirectUrl() == null) {
        throw new \InvalidArgumentException('Error al intentar conectar con klap Checkout. Por favor intenta más tarde.');
      }

      //actualiza/establece los metadatos de la orden
      $orderId = $response->getOrderId();
      $purchaseDate = $this->getCurrentDateTime();

      //actualiza la orden a pagada
      $orderStatus = $this->hp->getOrderStatusPendingPayment();
      $orderEcommerce->setState($orderStatus)->setStatus($orderStatus);

      $this->addMetadataToOrder($orderEcommerce, self::ORDER_ID, $orderId);
      $this->addMetadataToOrder($orderEcommerce, self::REFERENCE_ID, $referenceId);
      $this->addMetadataToOrder($orderEcommerce, self::AMOUNT, number_format($amount, 0, ',', '.'));
      $this->addMetadataToOrder($orderEcommerce, self::PURCHASE_DATE, $purchaseDate);

      $orderEcommerce->save();

      $this->logger->info('Orden creada con exito usando [Klap Checkout] en espera del pago, referenceId: ' . $referenceId . ', orderId: ' . $orderId . ', fecha: ' . $purchaseDate);

      return $this->resultRedirectFactory->create()->setUrl($response->getRedirectUrl());

    } catch(\Exception $ex) {
      $this->logger->error('order: ' . $referenceId . ', error: ' . $ex->getMessage(), $ex);
      $this->_checkoutSession->restoreQuote();
      $this->_messageManager->addError($ex->getMessage());
      return $this->resultRedirectFactory->create()->setPath('checkout/cart');
    }
  }
}
